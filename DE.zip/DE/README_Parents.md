# ZAptieka: Parent / Child вариации (UK и DE), 21.10.2026

Файлы собраны на основе категорийных отчётов `UK/DE Category+Listings+Report_10-21-2026.xlsm`.
Листы, выпадающие списки и строки 1–6 сохранены, в строках с 7-й только вариации.
Проверки агента:
- Feeds: dry run (0 FAIL), xlsm_patch, workbook_guard (PASS);
- SEO `content_check.py`: 0 ERROR и 0 WARN по всем Parent;
- аудит правил вариаций.

| Файл | Parent | Child |
|---|---|---|
| `UK_Parents_Variations_2026-10-21.xlsm` (лист Template) | 5 | 20 |
| `DE_Parents_Variations_2026-10-21.xlsm` (лист Vorlage) | 1 | 3 |

## Parent-строки

Действие: «Create or Replace (Full Update)» / «Erstellen oder Ersetzen». Заполнены поля: SKU, Product Type,
Parentage = Parent, Variation Theme, Title, Item Highlight, Brand, Manufacturer, Browse Node, 3 Bullets,
Description, Country of Origin, Dangerous Goods. GTIN, цены, размеры и Scent в Parent не ставятся
(правило наследования агента, раздел 59).

Требования из агента (`content_limits.json`, правила claims):
- Title ≤ 75 знаков. Только бренд может быть ЗАГЛАВНЫМИ, без промо-фраз, одно слово не больше 2 раз.
- Item Highlight ≤ 125 знаков, фразы через запятую, без слов из Title. Показывается, только если Title короче 75 знаков.
- Bullet 10–255 знаков, без эмодзи и без точки в конце.
- Description ≤ 2000 знаков, обычный текст без HTML.
- Без неподтверждённых заявлений: natural, organic, anti-aging, hair growth и т.п.

| Parent SKU | Title (знаков) | Highlight | Bullets 1/2/3 | Description |
|---|---|---|---|---|
| UK-Parent-1 | ZAptieka Soap Bar for Face and Body, 100 g (42) | 97 | 194/101/104 | 356 |
| UK-Parent-2 | ZAptieka Face Cream 60 ml, Moisturiser for Day and Night Care (61) | 100 | 205/106/106 | 328 |
| UK-Parent-3 | ZAptieka Body Lotion 125 ml, Daily Moisturiser for Dry Skin (59) | 76 | 133/82/96 | 252 |
| UK-Parent-4 | ZAptieka Rosemary Hair Care, Shampoo, Conditioner and Serum Oil (63) | 91 | 183/99/100 | 347 |
| UK-Parent-5 | ZAptieka Cold Pressed Seed Oil 100 ml (37) | 74 | 144/90/100 | 283 |
| DE-Parent-1 | ZAptieka Gesichtscreme 60 ml, Feuchtigkeitscreme für Tag und Nacht (66) | 87 | 179/94/103 | 308 |

## Child-строки

Действие: «Edit (Partial Update)» / «Bearbeiten». Меняются только:
- Parentage Level = Child, Parent SKU и Variation Theme;
- атрибуты темы (Colour, Colour Map, Size или Scent);
- Swatch Image URL.

Контент, цены и остатки не затрагиваются.

**Миниатюры (micro-картинки).** Тема Color, где Amazon это позволяет. Плюс у каждого Child заполнен
Swatch Image URL, равный его текущему главному фото на Amazon.
**Colour Map** — доминирующий цвет упаковки, определён по главным фото: мыло — White (белая коробка),
шампунь — Brown (коричневый флакон), масла — Black (тёмная бутылка). У кондиционера (Green) и сыворотки (Beige)
Colour Map уже был в листинге и оставлен как есть.

| Parent | Тема | Child SKU = Colour / Scent (Size) |
|---|---|---|
| UK-Parent-1 (SKIN_CLEANING_AGENT) | COLOR/SIZE | 2L-CFOT-WAF5 = Camel Milk · AL-OBXA-2JAB = Goats Milk · 79-IMQK-CFL6 = Milk and Honey · BO-LDT0-9J23 = Turmeric · O7-OU4A-2PTM = Black Seed Oil · RY-63EN-QQ04 = Sidr Leaf · SO-33NV-Y8TE = Charcoal · WJ-9EH3-NUHN = Frankincense (у всех Size 100 g) |
| UK-Parent-2 (SKIN_MOISTURIZER) | SCENT | 47-TYVC-KKS9 = Camel Milk and Hyaluronic Acid · MQ-GW44-AUVE = Goats Milk and Hyaluronic Acid · 5M-COWO-NTC4 = Shea Butter and Frankincense · N4-FRNJ-Q53V = Turmeric and Orange · TG-5RTH-70GN = Moringa |
| UK-Parent-3 (SKIN_MOISTURIZER) | SCENT | F8-4Y8G-GT5L = Camel Milk · UX-E5I6-5O5L = Goats Milk |
| UK-Parent-4 (SHAMPOO, все дети тоже SHAMPOO) | COLOUR | 2M-RLDD-XQAY = Shampoo 250 ml · YJ-OPSZ-IOCI = Conditioner 250 ml · BF-UJUW-N586 = Serum Oil 100 ml |
| UK-Parent-5 (EDIBLE_OIL_VEGETABLE) | COLOR/SIZE | GO-HRO6-WM8V = Black Seed · H3-5FMC-FAD4 = Rocket Seed (оба Size 100 ML) |
| DE-Parent-1 (SKIN_MOISTURIZER) | DUFT | 47-TYVC-KKS9 = Kamelmilch & Hyaluronsäure · MQ-GW44-AUVE = Ziegenmilch & Hyaluronsäure · 5M-COWO-NTC4 = Sheabutter & Weihrauch |

**Почему кремы и лосьоны не на Color.** В шаблонах UK и DE для SKIN_MOISTURIZER нет ни одной действующей
темы с COLOR, только SCENT/DUFT, SIZE, SKIN_TYPE и т.п. Swatch Image URL им добавлен. Покажет ли Amazon
для Scent картинки, а не текстовые кнопки, решает сам Amazon, гарантировать это нельзя.

## Риски, которые стоит знать до загрузки

1. **UK-Parent-4 (розмарин).** По вашему решению от 21.10 вся группа в Product Type SHAMPOO:
   - YJ-OPSZ-IOCI (кондиционер) — было CONDITIONER;
   - BF-UJUW-N586 (сыворотка) — было TOPICAL_HAIR_REGROWTH_TREATMENT.

   Смена типа идёт частичным обновлением. Amazon может:
   - потребовать атрибуты, обязательные для SHAMPOO;
   - отклонить смену типа у существующего ASIN (тогда это делается через Seller Support или обращение
     в каталог).

   Старые Browse Node детей (Conditioners, Hair Regrowth Treatments) в файл не передаются и остаются как
   есть. В DE из этой линейки есть только шампунь, поэтому группа сделана только для UK.
2. **UK-Parent-5 (масла).** Это два разных масла под темой COLOR/SIZE. Amazon может посчитать такую
   вариацию недопустимой. У GO-HRO6-WM8V тема SIZE заменена на COLOR/SIZE.
3. **Colour = название рецептуры.** В поле Colour записано название варианта, например «Charcoal», а не
   цвет. Так Amazon показывает подпись под миниатюрой. Настоящий цвет передаётся через Colour Map.
   У кондиционера и сыворотки старое значение Colour «Beige» заменено на название варианта.
4. **Значения Scent/Duft.** 6 значений Scent UK и 3 Duft DE не входят в рекомендуемые списки Amazon.
   Списки не строгие, свой текст допускается.
5. **Не включены:**
   - DP-ZW1J-GZYS Shea & Geranium Body Cream (по вашему решению);
   - Toner, Sunscreen, Bronzing Oil, а в DE Shampoo и Bronzing Oil: это единственные товары, пары нет.

После загрузки скачайте Processing Report. Если будут ошибки, его можно отдать агенту Feeds в режиме ERRORS.
